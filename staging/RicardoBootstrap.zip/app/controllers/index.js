// do anything you need before the first screen

Alloy.createController('home').getView().open();
